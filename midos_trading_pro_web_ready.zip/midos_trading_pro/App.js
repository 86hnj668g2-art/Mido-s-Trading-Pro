import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { SafeAreaView, ScrollView, View, Text, TouchableOpacity, TextInput, StatusBar, StyleSheet } from 'react-native';

const GREEN = '#39E58C', BG = '#07110D', PANEL = '#101D17', MUTED = '#91A69A', WHITE = '#F2F8F4', RED = '#FF6875';
const money = n => Number.isFinite(n) ? n.toFixed(2) : '—';

function Card({children, style}) { return <View style={[s.card, style]}>{children}</View>; }
function Tag({children, color=GREEN}) { return <View style={[s.tag,{borderColor:color}]}><Text style={{color,fontSize:11,fontWeight:'800'}}>{children}</Text></View>; }
function Metric({label,value,accent=WHITE}) { return <View style={{flex:1}}><Text style={s.muted}>{label}</Text><Text style={[s.metric,{color:accent}]}>{value}</Text></View>; }

export default function App() {
  const [tab,setTab] = useState('Home');
  const [balance,setBalance] = useState('1000');
  const [risk,setRisk] = useState('1');
  const [entry,setEntry] = useState('');
  const [stop,setStop] = useState('');
  const [target,setTarget] = useState('');
  const [journal,setJournal] = useState([]);
  const [note,setNote] = useState('');
  const [side,setSide] = useState('BUY');
  const [tick,setTick] = useState(null);
  const [bars,setBars] = useState({m5:[],m15:[],h1:[]});
  const [feedStatus,setFeedStatus] = useState('Connecting');
  const [feedError,setFeedError] = useState('');
  const [lastUpdated,setLastUpdated] = useState(null);

  const refreshMarket = useCallback(async () => {
    try {
      const [tickRes,m5Res,m15Res,h1Res] = await Promise.all([
        fetch('https://biquote.io/api/XAUUSD?allowStale=false'),
        fetch('https://biquote.io/api/XAUUSD/ohlc?interval=5m&limit=120'),
        fetch('https://biquote.io/api/XAUUSD/ohlc?interval=15m&limit=120'),
        fetch('https://biquote.io/api/XAUUSD/ohlc?interval=1h&limit=120')
      ]);
      if (!tickRes.ok || !m5Res.ok || !m15Res.ok || !h1Res.ok) throw new Error('Market feed unavailable. Check again shortly.');
      const [t,a,b,c] = await Promise.all([tickRes.json(),m5Res.json(),m15Res.json(),h1Res.json()]);
      if (!Number.isFinite(Number(t.mid)) || t.stale || t.marketState !== 'open') throw new Error('No fresh live Gold quote. Signal engine paused.');
      setTick(t); setBars({m5:(a.bars||[]).filter(x=>!x.isOpen).reverse(),m15:(b.bars||[]).filter(x=>!x.isOpen).reverse(),h1:(c.bars||[]).filter(x=>!x.isOpen).reverse()});
      setFeedStatus('Live feed connected'); setFeedError(''); setLastUpdated(new Date());
    } catch(e) { setFeedStatus('Feed unavailable'); setFeedError(e.message || 'Could not load market data'); setTick(null); }
  },[]);
  useEffect(() => { refreshMarket(); const timer=setInterval(refreshMarket,15000); return ()=>clearInterval(timer); },[refreshMarket]);

  const ema = (values, period) => { if(values.length<period) return null; const k=2/(period+1); let v=values.slice(0,period).reduce((x,y)=>x+y,0)/period; for(let i=period;i<values.length;i++) v=values[i]*k+v*(1-k); return v; };
  const rsi = values => { if(values.length<15) return null; let gains=0,losses=0; for(let i=values.length-14;i<values.length;i++){const d=values[i]-values[i-1]; if(d>0)gains+=d; else losses-=d;} if(losses===0)return 100; return 100-100/(1+gains/14/(losses/14)); };
  const closes = key => bars[key].map(x=>Number(x.close)).filter(Number.isFinite);
  const m5=closes('m5'), m15=closes('m15'), h1=closes('h1');
  const ema50=ema(m15,50), ema200=ema(h1,100), rsi14=rsi(m5);
  const signal = tick && ema50!==null && ema200!==null && rsi14!==null && m5.length>20 ? (tick.mid>ema50 && m15[m15.length-1]>ema50 && m15[m15.length-1]>ema200 && rsi14>50 && rsi14<70 ? 'BUY' : tick.mid<ema50 && m15[m15.length-1]<ema50 && m15[m15.length-1]<ema200 && rsi14<50 && rsi14>30 ? 'SELL' : 'WAIT') : 'WAIT';
  const calc = useMemo(() => {
    const b=Number(balance), r=Number(risk), e=Number(entry), sl=Number(stop), tp=Number(target);
    const riskCash=b*r/100, distance=Math.abs(e-sl), units=distance>0?riskCash/distance:0;
    const reward=Math.abs(tp-e), rr=distance>0?reward/distance:0;
    return {riskCash,units,rr};
  },[balance,risk,entry,stop,target]);

  const addJournal = () => { if (!note.trim()) return; setJournal([{id:Date.now(),note:note.trim(),side},...journal]); setNote(''); };

  const Header = () => <View style={s.header}><View><Text style={s.brand}>MIDO'S <Text style={{color:GREEN}}>TRADING PRO</Text></Text><Text style={s.subbrand}>PRECISION • DISCIPLINE • PROCESS</Text></View><View style={s.logo}><Text style={{color:GREEN,fontSize:21,fontWeight:'900'}}>M</Text></View></View>;
  const Nav = () => <View style={s.nav}>{['Home','Analysis','Risk','Journal'].map(x=><TouchableOpacity key={x} onPress={()=>setTab(x)} style={[s.navItem,tab===x&&s.navActive]}><Text style={[s.navText,tab===x&&{color:GREEN}]}>{x}</Text></TouchableOpacity>)}</View>;

  return <SafeAreaView style={s.safe}><StatusBar barStyle="light-content" backgroundColor={BG}/><Header/><ScrollView contentContainerStyle={s.content}>
    {tab==='Home' && <>
      <View style={s.rowBetween}><Text style={s.heading}>Market overview</Text><Tag color={tick?GREEN:'#F2C66D'}>{tick?'LIVE INDICATIVE FEED':'FEED OFFLINE'}</Tag></View>
      <Card>
        <View style={s.rowBetween}><Text style={s.label}>GOLD / US DOLLAR</Text><Tag color={MUTED}>XAU/USD</Tag></View>
        <Text style={s.price}>{tick?'$'+money(Number(tick.mid)):'—'}</Text><Text style={s.muted}>{tick?`Bid ${money(Number(tick.bid))} · Ask ${money(Number(tick.ask))} · Spread ${money(Number(tick.spread))}`:'No verified live quote available'}</Text><Text style={s.muted}>{tick?`Source: ${tick.source||'third-party MT5 feed'} · ${tick.timestamp?new Date(tick.timestamp).toLocaleTimeString():''}`:feedError}</Text>
        <View style={[s.divider,{marginVertical:16}]}/>
        <View style={s.rowBetween}><Metric label="Connection" value={feedStatus} accent={tick?GREEN:'#F2C66D'}/><Metric label="Trading platform" value="MT5"/><Metric label="Execution" value="Manual"/></View>
      </Card>
      <Text style={s.heading}>Your scalping workspace</Text>
      <View style={s.grid}><Card style={s.smallCard}><Text style={s.muted}>Primary timeframe</Text><Text style={s.metric}>M5</Text><Text style={s.muted}>Entry timing</Text></Card><Card style={s.smallCard}><Text style={s.muted}>Confirmation</Text><Text style={s.metric}>M15</Text><Text style={s.muted}>Trend filter: H1</Text></Card></View>
      <Card><Text style={s.cardTitle}>Signal status</Text><Text style={[s.bigStatus,{color:signal==='BUY'?GREEN:signal==='SELL'?RED:'#F2C66D'}]}>{signal}</Text><Text style={s.body}>{tick?`Rule-based indication only. RSI(14): ${rsi14?.toFixed(1)??'—'} · M15 EMA50: ${ema50?.toFixed(2)??'—'} · H1 EMA100: ${ema200?.toFixed(2)??'—'}. Confirm the quote and setup in XM MT5 before trading.`:'No fresh market data. Signal engine paused; no BUY/SELL recommendation.'}</Text><TouchableOpacity onPress={refreshMarket} style={s.button}><Text style={s.buttonText}>Refresh market data</Text></TouchableOpacity></Card>
      <Card><Text style={s.cardTitle}>Quick checklist</Text>{['Check H1 market direction','Mark M15 support and resistance','Wait for M5 setup confirmation','Set stop loss before entry','Risk no more than your planned percentage'].map((x,i)=><Text key={i} style={s.check}>✓  {x}</Text>)}</Card>
    </>}
    {tab==='Analysis' && <>
      <Text style={s.heading}>Technical analysis</Text><Tag color={tick?GREEN:'#F2C66D'}>{tick?'THIRD-PARTY MT5 FEED':'AWAITING LIVE DATA'}</Tag>
      <Card><Text style={s.cardTitle}>Indicator panel</Text>{[['M15 EMA 50',ema50?.toFixed(2)||'Waiting for candles'],['H1 EMA 100',ema200?.toFixed(2)||'Waiting for candles'],['M5 RSI (14)',rsi14?.toFixed(1)||'Waiting for candles'],['MACD','Not yet implemented'],['ATR / support & resistance','Not yet implemented']].map(([a,b])=><View key={a} style={s.listRow}><Text style={s.body}>{a}</Text><Text style={s.muted}>{b}</Text></View>)}</Card>
      <Card><Text style={s.cardTitle}>Signal rules</Text><Text style={s.body}>A setup should only be considered when the H1 trend, M15 structure and M5 trigger agree. The app should show BUY, SELL or WAIT with the reasons and the time of the latest data.</Text></Card>
      <Card><Text style={s.cardTitle}>Timeframes</Text><View style={s.chips}>{['M5','M15','H1','H4'].map(x=><Tag key={x}>{x}</Tag>)}</View></Card>
    </>}
    {tab==='Risk' && <>
      <Text style={s.heading}>Risk calculator</Text><Text style={s.muted}>Estimate position sizing before placing a trade. Confirm contract specifications and lot value with your broker.</Text>
      <Card>
        <Text style={s.fieldLabel}>Account balance (account currency)</Text><TextInput value={balance} onChangeText={setBalance} keyboardType="decimal-pad" style={s.input}/>
        <Text style={s.fieldLabel}>Risk per trade (%)</Text><TextInput value={risk} onChangeText={setRisk} keyboardType="decimal-pad" style={s.input}/>
        <Text style={s.fieldLabel}>Entry price</Text><TextInput value={entry} onChangeText={setEntry} keyboardType="decimal-pad" placeholder="e.g. 2650.00" placeholderTextColor="#65776C" style={s.input}/>
        <Text style={s.fieldLabel}>Stop-loss price</Text><TextInput value={stop} onChangeText={setStop} keyboardType="decimal-pad" placeholder="e.g. 2648.00" placeholderTextColor="#65776C" style={s.input}/>
        <Text style={s.fieldLabel}>Take-profit price</Text><TextInput value={target} onChangeText={setTarget} keyboardType="decimal-pad" placeholder="e.g. 2654.00" placeholderTextColor="#65776C" style={s.input}/>
        <View style={s.divider}/><View style={s.rowBetween}><Metric label="Cash risk" value={Number.isFinite(calc.riskCash)?calc.riskCash.toFixed(2):'—'} accent={RED}/><Metric label="Price R:R" value={calc.rr?`1:${calc.rr.toFixed(2)}`:'—'} accent={GREEN}/></View>
        <Text style={[s.muted,{marginTop:12}]}>Estimated price-unit exposure: {calc.units?calc.units.toFixed(4):'—'} (not a broker lot size)</Text>
      </Card>
    </>}
    {tab==='Journal' && <>
      <Text style={s.heading}>Trading journal</Text><Card><Text style={s.cardTitle}>Record a trade or observation</Text><View style={s.chips}>{['BUY','SELL'].map(x=><TouchableOpacity key={x} onPress={()=>setSide(x)} style={[s.choice,side===x&&s.choiceActive]}><Text style={{color:side===x?GREEN:WHITE,fontWeight:'800'}}>{x}</Text></TouchableOpacity>)}</View><TextInput value={note} onChangeText={setNote} placeholder="Write your setup, reason, result or lesson..." placeholderTextColor="#65776C" multiline style={[s.input,{height:100,textAlignVertical:'top'}]}/><TouchableOpacity onPress={addJournal} style={s.button}><Text style={s.buttonText}>Save journal note</Text></TouchableOpacity></Card>
      {journal.map(j=><Card key={j.id}><View style={s.rowBetween}><Tag>{j.side}</Tag><Text style={s.muted}>{new Date(j.id).toLocaleString()}</Text></View><Text style={[s.body,{marginTop:10}]}>{j.note}</Text></Card>)}
      {journal.length===0&&<Text style={s.muted}>Your saved notes will appear here on this session.</Text>}
    </>}
    <Text style={s.footer}>Mido's Trading Pro · Free third-party market feed, not XM quotes. Indicative signals only; verify bid/ask and execution in XM MT5. Trading involves risk.</Text>
  </ScrollView><Nav/></SafeAreaView>;
}

const s=StyleSheet.create({safe:{flex:1,backgroundColor:BG},header:{paddingHorizontal:20,paddingTop:14,paddingBottom:12,flexDirection:'row',justifyContent:'space-between',alignItems:'center',borderBottomWidth:1,borderBottomColor:'#1D3025'},brand:{color:WHITE,fontSize:17,fontWeight:'900',letterSpacing:1},subbrand:{color:MUTED,fontSize:9,letterSpacing:1.3,marginTop:4},logo:{width:40,height:40,borderRadius:13,borderWidth:1,borderColor:GREEN,alignItems:'center',justifyContent:'center',backgroundColor:'#10251A'},content:{padding:18,paddingBottom:28,gap:14},heading:{color:WHITE,fontSize:20,fontWeight:'800',marginTop:4},card:{backgroundColor:PANEL,borderRadius:16,padding:16,borderWidth:1,borderColor:'#20372A',gap:9},smallCard:{flex:1,minHeight:105},rowBetween:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',gap:12},row:{flexDirection:'row',gap:10},label:{color:MUTED,fontSize:11,fontWeight:'800',letterSpacing:1},price:{color:WHITE,fontSize:34,fontWeight:'900',marginTop:6},muted:{color:MUTED,fontSize:12},metric:{color:WHITE,fontSize:19,fontWeight:'800',marginTop:5},tag:{borderWidth:1,borderRadius:20,paddingHorizontal:10,paddingVertical:5,alignSelf:'flex-start'},divider:{height:1,backgroundColor:'#294034',marginVertical:8},cardTitle:{color:WHITE,fontSize:15,fontWeight:'800',marginBottom:4},bigStatus:{fontSize:27,fontWeight:'900'},body:{color:'#C0CEC5',fontSize:13,lineHeight:20},check:{color:'#C0CEC5',fontSize:13,paddingVertical:5},grid:{flexDirection:'row',gap:10},nav:{height:62,borderTopWidth:1,borderTopColor:'#20372A',backgroundColor:'#0B1710',flexDirection:'row',justifyContent:'space-around',alignItems:'center'},navItem:{paddingHorizontal:12,paddingVertical:10,borderRadius:12},navActive:{backgroundColor:'#12301F'},navText:{color:MUTED,fontSize:12,fontWeight:'700'},fieldLabel:{color:MUTED,fontSize:12,fontWeight:'700',marginTop:7},input:{backgroundColor:'#08130D',borderWidth:1,borderColor:'#294034',borderRadius:10,padding:12,color:WHITE,fontSize:15},listRow:{flexDirection:'row',justifyContent:'space-between',paddingVertical:12,borderBottomWidth:1,borderBottomColor:'#20372A'},chips:{flexDirection:'row',gap:8,flexWrap:'wrap',marginVertical:6},choice:{borderWidth:1,borderColor:'#385344',paddingHorizontal:18,paddingVertical:9,borderRadius:9},choiceActive:{borderColor:GREEN,backgroundColor:'#12301F'},button:{backgroundColor:GREEN,borderRadius:10,padding:14,alignItems:'center',marginTop:6},buttonText:{color:'#06120B',fontWeight:'900'},footer:{color:'#63766A',fontSize:10,textAlign:'center',marginTop:12,lineHeight:16}});
