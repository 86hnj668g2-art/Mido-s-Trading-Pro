# Mido's Trading Pro — free-feed mobile prototype

Black-and-green Expo / React Native starter for an XAU/USD scalping assistant.

## Included
- Mobile dashboard and navigation (Home, Analysis, Risk, Journal)
- Free third-party XAUUSD quote retrieval from biquote.io (REST)
- M5, M15 and H1 closed-candle retrieval from biquote.io
- Refresh every 15 seconds; stale/closed/unavailable quote blocks BUY/SELL indications
- Early rule-based indication using M15 EMA50, H1 EMA100 and M5 RSI(14)
- Basic cash-risk and price-risk/reward calculator
- Session-only trading journal

## Run
1. Install Node.js LTS on a computer (or use a cloud development environment).
2. In this folder run `npm install`.
3. Run `npx expo start`.
4. Install Expo Go on your iPhone and scan the QR code shown by Expo.

The iPhone can run the app, but the initial Expo project still needs a development environment to build/serve it. It is not yet an App Store installation.

## Market-data limitations — read before trading
- The free feed is **biquote.io**, not a direct XM account connection. Its public documentation describes its XAUUSD ticks as sourced from an MT5 feed, and OHLC bars as a combination of tick aggregation, MT5 history and bootstrap data. It is not guaranteed to match XM's symbol, spread, bid/ask, execution price or server time.
- The quote is indicative third-party market data. Always compare it with the live XAUUSD quote in your XM MT5 app before making any decision. Do not use this prototype as an execution or order-pricing source.
- The free integration uses REST snapshots, not a guaranteed low-latency tick stream. It refreshes every 15 seconds. This is **not suitable as a standalone source for fast scalping or trade execution**.
- Signals are experimental rule-based indications, not validated predictions or financial advice. WAIT is used when the data is missing or stale. No trades are placed.
- The first signal rules use M15 EMA50, H1 EMA100 and M5 RSI(14). MACD, ATR, support/resistance, push notifications, persistent journal storage and proper backtesting are not implemented yet.
- The free API may change, become unavailable, or impose limits. The app fails closed rather than inventing prices.

## Security
No XM login or password is requested or stored. Do not put broker credentials in the app. Keep all trading execution disabled; this project is signals-only.

## Risk calculator
The exposure figure is a price-unit estimate, not a broker lot-size recommendation. Gold contract size, tick value, account currency conversion and minimum volume vary by broker and must be configured from XM's current contract specifications before sizing trades.


## Web app deployment (iPhone-friendly)
This project has been configured for Expo web export. It still needs to be built and hosted before it can be added to an iPhone Home Screen.

Build command: `npx expo export --platform web`
The generated website is in `dist/`. Deploy `dist/` to a static HTTPS host. For Expo Hosting, use the EAS CLI deployment flow documented at https://docs.expo.dev/eas/hosting/get-started/.

After the site is deployed, open its HTTPS URL in Safari on iPhone, tap Share, then Add to Home Screen. This is a web app shortcut/PWA-style experience, not an App Store native app.
